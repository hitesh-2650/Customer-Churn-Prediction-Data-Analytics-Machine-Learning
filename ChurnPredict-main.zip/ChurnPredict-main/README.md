# 📉 Customer Churn Prediction System 🤖📊  

A full-stack machine learning web application designed to predict customer churn based on service usage and account details.  
The system enables businesses to identify high-risk customers early and take proactive actions to improve retention and reduce revenue loss.

---

## 🚀 Project Overview  

Customer churn is a major challenge for businesses, especially in industries like telecom, banking, and SaaS, where retaining customers is more cost-effective than acquiring new ones.  

This project provides a **data-driven solution** that predicts whether a customer is likely to churn, helping organizations make informed decisions and implement targeted retention strategies.

The application allows users to input customer details and instantly receive a prediction along with a probability score, making the system both **practical and actionable**.

---

## 🧠 System Architecture  

The application follows a **layered architecture** integrating frontend, backend, and machine learning components:

- **Frontend (Client Layer)**  
  Built with React.js, responsible for collecting user input and displaying prediction results in an interactive interface.

- **Backend (API Layer)**  
  Developed using Flask, this layer handles request processing, data preprocessing, and communication with the machine learning model.

- **Machine Learning Layer**  
  Contains the trained model and preprocessing artifacts (encoders), stored as serialized files for efficient reuse.

This architecture ensures **scalability, maintainability, and real-time prediction capability**.

<img width="1024" height="559" alt="image" src="https://github.com/user-attachments/assets/97889e22-2d78-49ac-bc04-4b516913d753" />

---

## 🔁 Application Flow (How It Works)

1. User enters customer details through the frontend interface  
2. Data is sent to the Flask backend via REST API  
3. Backend validates and preprocesses the input data  
4. Encoders transform categorical features into numerical format  
5. Trained model is loaded from saved `.pkl` files  
6. Model predicts churn probability  
7. Result (Churn / No Churn + probability) is returned to the frontend  

This pipeline enables **fast and reliable real-time predictions**.

---

## 🏗️ Design Decisions  

This system was designed with production-readiness in mind:

- **Separation of Concerns**  
  Clear distinction between UI, backend logic, and ML model  

- **Model Serialization**  
  Using `.pkl` files avoids retraining and ensures faster inference  

- **Reusable Preprocessing Pipeline**  
  Encoders are saved and reused to maintain consistency  

- **API-Based Integration**  
  REST APIs ensure smooth communication between layers  

---

## 🧩 Key Features  

- 🔐 Structured and user-friendly input interface  
- ⚡ Real-time churn prediction  
- 📊 Probability-based output for better decision-making  
- 🧠 Integration of ML model into web application  
- 🔄 End-to-end pipeline from input to prediction  
- 📦 Modular and scalable system design  

---

## 🛠️ Tech Stack  

### 💻 Frontend  
- React.js  
- HTML5, CSS3, JavaScript  

### ⚙️ Backend  
- Flask (Python)  
- REST API  

### 🧠 Machine Learning  
- Scikit-learn  
- Random Forest Classifier  
- SMOTE (handling class imbalance)  
- Pickle (model & encoder serialization)  

---

## 📂 Project Structure  

```plaintext
customer-churn-prediction/
│
├── backend/                     # Flask API
│   ├── app.py                  # Main application entry point
│   ├── model/                  # ML artifacts
│   │   ├── model.pkl
│   │   └── encoders.pkl
│   ├── utils/                  # Preprocessing & helper functions
│   └── requirements.txt
│
├── frontend/                   # React application
│   ├── public/                 # Static assets
│   └── src/
│       ├── components/         # Reusable UI components
│       ├── pages/              # Input & result pages
│       ├── App.js              # Main component
│       └── index.js            # Entry point
│
├── .env.example                # Environment variables template
├── .gitignore
├── README.md
```
---

## 🔐 Backend Responsibilities  

- Load trained machine learning model and preprocessing encoders  
- Validate and preprocess incoming user input data  
- Transform categorical features using pre-fitted encoders  
- Execute prediction logic using the trained model  
- Handle API requests and return structured responses to the frontend  

---

## 🎯 Frontend Responsibilities  

- Provide an intuitive interface for entering customer details  
- Capture and validate user input through forms  
- Send data to backend APIs via HTTP requests  
- Display prediction results (churn status and probability)  
- Ensure a smooth and responsive user experience  

---

## 🧪 Challenges & Learnings  

During the development of this project, several real-world challenges were addressed:

- Handling imbalanced datasets using SMOTE to improve model performance  
- Maintaining consistency between training and inference pipelines  
- Integrating machine learning models into a full-stack application  
- Designing a system capable of real-time predictions  

This project strengthened my understanding of:

- End-to-end machine learning workflows  
- Model deployment and integration  
- REST API development using Flask  
- Building scalable and modular full-stack applications  

---

## 📈 Future Improvements  

- 🌐 Deploy the application on cloud platforms (AWS / GCP)  
- 📊 Add advanced visualization dashboards for better insights  
- 🔐 Implement authentication and user management  
- ⚡ Optimize model performance and reduce latency  
- 🔔 Add logging, monitoring, and real-time analytics  

---

## 🧑‍💻 Author  

**Sai Uday Kiran Rayapudi**  
Full Stack Developer | AI/ML Enthusiast  

